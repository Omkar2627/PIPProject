// TaskStatus.java
package com.taskmgmt.entity;

public enum TaskStatus {
    TODO, IN_PROGRESS, DONE
}
