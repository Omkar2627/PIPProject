package com.taskmgmt.entity;

public enum Role {
    ADMIN, USER
}
